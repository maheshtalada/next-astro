export default function LoadMore() {
  return <button onClick={() => alert("Load More...")} style={{padding:'10px', background: "green", 'fontSize': "20px"}}>LoadMore</button>;
}
