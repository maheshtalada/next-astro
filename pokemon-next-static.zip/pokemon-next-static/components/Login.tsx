export default function Login() {
  return <button onClick={() => alert("login")}>Login</button>;
}
