export default function LoadMore() {
  return <button onClick={() => alert("Load More...")}>LoadMore</button>;
}
