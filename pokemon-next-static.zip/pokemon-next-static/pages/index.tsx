import type { NextPage } from "next";

import { Pokemon } from "../src/types";
import PokemonList from "../components/PokemonList";
import Login from "../components/Login";
import LoadMore from "../components/LoadMore";
import pokemon from "./pokemon.json";

export function getStaticProps() {
  return {
    props: {
      pokemon,
    },
  };
}

const Home: NextPage<{
  pokemon: Pokemon[];
}> = ({ pokemon }: { pokemon: Pokemon[] }) => {
  return (
    <div>
      <h1 style={{textAlign: 'center'}}>NextJS APP</h1>
      <Login />
      <PokemonList pokemon={pokemon} />
      <LoadMore />
    </div>
  );
};

export default Home;
